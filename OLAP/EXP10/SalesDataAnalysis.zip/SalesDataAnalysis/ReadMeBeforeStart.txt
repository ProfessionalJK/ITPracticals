Hi All,

As I am posting this solution later after a long time.

You can use following Development Environment to open this solution, and change credentials in data source as per your machine and SQL server instance you have.

Microsoft SQL Server Data Tools - Business Intelligence for Visual Studio 2012

it is free for download
http://www.microsoft.com/en-us/download/details.aspx?id=36843


I hope you will enjoy the learning.

Regards,
Mubin